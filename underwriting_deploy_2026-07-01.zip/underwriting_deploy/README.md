# AI Real Estate Underwriting SaaS

Lightweight deal-screening tool that returns GO / REVIEW / NO-GO with full metrics and risk flags. Supports Fix-and-Flip, Multifamily, and Development deals.

## Quick Deploy (Streamlit Community Cloud)

1. Push these files to a new GitHub repo
2. Go to [streamlit.io/cloud](https://streamlit.io/cloud)
3. Connect your GitHub → import this repo
4. Streamlit auto-detects `underwriting_streamlit_app.py` as the entry point
5. Deploy!

## Quick Deploy (Render)

1. Push these files to a new GitHub repo
2. Create a new **Web Service** on [render.com](https://render.com)
3. Connect your GitHub → select this repo
4. Set:
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `streamlit run underwriting_streamlit_app.py --server.port $PORT --server.address 0.0.0.0`
5. Deploy!

## Local Run

```bash
python3 -m pip install -r requirements.txt
PYTHONPATH=. streamlit run underwriting_streamlit_app.py
```

## What It Does

- Enter deal parameters (purchase price, ARV, rehab costs, financing)
- Get instant GO / REVIEW / NO-GO recommendation
- See full metrics: ROI, cap rate, DSCR, cash-on-cash, equity multiple
- Red flag analysis with specific failure points
- Supports 3 deal types: Fix-and-Flip, Multifamily, Development

## Pricing (Target)

- Self-Serve Beta: $197/month
- Team Beta: $497/month
- Concierge Setup: $1,500 + $500/month
